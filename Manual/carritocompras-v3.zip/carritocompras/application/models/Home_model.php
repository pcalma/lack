<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model {


	public function getProducts()
	{
        $this->db->select("p.*");
        $this->db->from("product p");
        $results = $this->db->get();

        return $results->result();
	}
}
