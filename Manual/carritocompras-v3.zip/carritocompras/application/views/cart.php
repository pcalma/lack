<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Ionicons CSS -->
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
    <!-- App CSS -->
    <link href="<?php echo base_url(); ?>assets/css/app.css" rel="stylesheet">

    <title>Hello, world!</title>

  </head>
  <body>
    <div class="pt-5 text-center">
        <h1>Carrito de compras</h1>
    </div>

    <div class="container pt-5">
        <div class="row">

            <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Produto</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Cantidad</th>
                    <th scope="col">Subtutal</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>

                <?php foreach($this->session->userdata() as $product): ?>

                   <?php if(is_object($product)): ?>

                    <tr>
                        <td><img src="<?php echo base_url(); ?>assets/images/img<?php echo $product->id; ?>.jpg" width="180" alt="..."></td>
                        <td class="pt-5"><?php echo $product->price; ?></td>
                        <td class="pt-5"><input id="<?php echo $product->id; ?>" type="text" name="cant" value="<?php echo $product->cant; ?>" class="form-control"></td>
                        <td class="pt-5"><?php echo number_format($product->cant*$product->price,2,'.',''); ?></td>
                        <td class="pt-5"><button id="<?php echo $product->id; ?>" class="btn btn-danger btn-delete"><i class="icon ion-md-trash"></i></button></td>
                    </tr>

                   <?php endif; ?>
                
                <?php endforeach; ?>
     
                </tbody>
              </table>
              
              

        </div>

        <a href="<?php echo base_url(); ?>" class="btn btn-primary">Seguir comprando</a>
        <h4 class="text-right">Total <span id="total" class="text-dark" >$300.00</span></h4>

    </div>

    <!-- jQuery  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        $(function(){
            

            getTotal();

            
            $(document).on("click",".btn-delete",function(){

                $(this).parent().parent().remove();

                getTotal();

                deleteProduct(this.id);

            });

            $(document).on("keyup","input[name*=cant]",function(){


                id=this.id;
                cant=$(this).val();
                price=$(this).closest("tr").find("td:eq(1)").html();
                SubTutal=cant*price;

                $(this).closest("tr").find("td:eq(3)").html(SubTutal.toFixed(2));
                
                getTotal();

                addCant(id,price,cant);

            }); 
            
        });

        function getTotal(){
            total=0;
            $("tbody tr").each(function(){
                total=total+Number($(this).find("td:eq(3)").html());
            });
            
            $("#total").html("$"+total.toFixed(2));
        }

        function addCant(id,price,cant){
            $.ajax({
                url:"<?php echo base_url(); ?>Cart/addCant",
                type:"POST",
                dataType:"json",
                data:{id:id,price:price,cant:cant}
            })

        }

        function deleteProduct(id){
            $.ajax({
                url:"<?php echo base_url(); ?>Cart/deleteProduct",
                type:"POST",
                dataType:"json",
                data:{id:id}
            })
        }

    </script>
</body>
</html>