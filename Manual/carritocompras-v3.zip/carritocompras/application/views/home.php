<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!-- Ionicons CSS -->
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
    <!-- App CSS -->
    <link href="<?php echo base_url(); ?>assets/css/app.css" rel="stylesheet">

    <title>Hello, world!</title>

  </head>
  <body>
    <div class="pt-5 text-center">
        <h1>Productos <a href="<?php echo base_url(); ?>Cart" class="btn btn-success"><sup><?php echo count($this->session->userdata())-1; ?></sup> <i class="icon ion-md-cart"></i></a></h1>
    </div>

    <div class="container pt-5">
        <div class="row">
          <?php foreach($products as $product): ?>
            <div class="col-sm-3">
                <div class="card">
                    <img src="<?php echo base_url(); ?>assets/images/<?php echo $product->picture; ?>" class="card-img-top" height="200" alt="...">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo $product->name; ?></h5>
                      <p class="card-text">$ <span id="price"><?php echo $product->price; ?></span></p>
                      <buttom id="<?php echo $product->id; ?>" class="btn btn-primary btn-add"><i class="icon ion-md-cart"></i></buttom>
                    </div>
                  </div>
            </div>
          <?php endforeach; ?>

        </div>
    </div>

    <!-- jQuery  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
      $(function(){

        $(".btn-add").on("click",function(){
            id=this.id;
            price=$(this).closest("div").find("#price").html();
            addCart(id, price);
        });

      });

      function addCart(){
        $.ajax({
          url:"<?php echo base_url(); ?>Home/addCart",
          type:"POST",
          dataType:"json",
          data:{id:id,price:price},
          success:function(data){
            location.href="<?php echo base_url(); ?>Cart";
          }
        })
      }
    </script>
 </body>
</html>