<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {


	public function index()
	{
		$this->load->view('cart');
	}

	function addCant(){
		
		$id	=	$this->input->post("id");
		$price	=	$this->input->post("price");
		$cant	=	$this->input->post("cant");

		$products = array(
			'key'.$id	=>(object) array(
				'id'	=> $id,
				'price'	=> $price,
				'cant'	=> $cant
			)
		);

		$this->session->set_userdata($products);
	}

	function deleteProduct(){
		
		$id	=	$this->input->post("id");

		$this->session->unset_userdata('key'.$id);
	}
}
