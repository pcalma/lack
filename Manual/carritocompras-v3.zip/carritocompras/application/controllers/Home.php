<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->model("Home_model");
	}

	public function index()
	{	
		$data =	array(
			'products'	=> 	$this->Home_model->getProducts()
		);
		$this->load->view('home', $data);
	}
	
	function addCart(){
		
		$id	=	$this->input->post("id");
		$price	=	$this->input->post("price");

		$products = array(
			'key'.$id	=>(object) array(
				'id'	=> $id,
				'price'	=> $price,
				'cant'	=> 1
			)
		);

		if(!$this->session->has_userdata('key'.$id)){
			$this->session->set_userdata($products);
		}

		echo json_encode('success');
	}
}
